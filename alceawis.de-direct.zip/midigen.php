<?php
$defaultDirectory = 'other/music/midi/piano/';
$directory = isset($_GET['path']) ? $_GET['path'] : $defaultDirectory;

// Sanitize the directory path
$directory = rtrim($directory, '/') . '/';

// Scan the directory for MIDI files
$files = glob($directory . '*.mid');

// Create a linked list of target blank links
$linkList = '<ul>';
foreach ($files as $file) {
    $filename = basename($file);
    $linkList .= '<li><a href="' . $file . '" target="_blank">' . $filename . '</a></li>';
}
$linkList .= '</ul>';

// Output the linked list and the form
echo '<form method="get" action="">';
echo 'Folder: <input type="text" name="path" value="' . $directory . '">';
echo '<input type="submit" value="Generate List">';
echo '</form>';
echo $linkList;
?>