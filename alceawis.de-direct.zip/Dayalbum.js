<a target="_blank" href="https://vgmdb.net/album/128657">Sin Chronicle MEMORIAL SOUNDTRACK</a>
<a target="_blank" href="https://vgmdb.net/album/133710">Crymachina</a>